package com.demo.modules.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.modules.order.entity.UserOrder;

public interface UserOrderMapper extends BaseMapper<UserOrder> {
}
