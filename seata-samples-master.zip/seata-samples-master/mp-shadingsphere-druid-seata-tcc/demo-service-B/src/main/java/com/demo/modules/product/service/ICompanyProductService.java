package com.demo.modules.product.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.modules.product.entity.CompanyProduct;

public interface ICompanyProductService extends IService<CompanyProduct> {
}
