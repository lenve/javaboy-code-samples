package com.demo.modules.product.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.modules.product.entity.CompanyProduct;

public interface CompanyProductMapper extends BaseMapper<CompanyProduct> {
}
