package io.seata.samples.jit;

/**
 * @author ppf
 * @Date 2020/7/31
 */
public interface Starter {
    /**
     * 开启服务
     *
     * @param args
     */
    void start(String[] args);
}
